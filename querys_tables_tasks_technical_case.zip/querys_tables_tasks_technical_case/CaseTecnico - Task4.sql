SELECT a.country,
CAST(((SUM(c.cancelled) +  SUM(c.refund))/count(c.purchase_id)) * 100 as 
DECIMAL (10,2)) as '%LOSS_PERFORMANCE'
FROM hotmart.produtores as a
INNER JOIN hotmart.produtos as b ON a.producer_id = b.producer_id
INNER JOIN hotmart.vendas as c ON b.product_id = c.product_id
WHERE b.type = 'Assinatura'
GROUP BY a.country;