SELECT 
    CASE DAYOFWEEK(purchase_date)
        WHEN 1 THEN 'Domingo'
        WHEN 2 THEN 'Segunda'
        WHEN 3 THEN 'Terça'
        WHEN 4 THEN 'Quarta'
        WHEN 5 THEN 'Quinta'
        WHEN 6 THEN 'Sexta'
        WHEN 7 THEN 'Sábado'
    END AS DIA_SEMANA,
    SUM(CASE WHEN YEAR(purchase_date) = 2020 THEN 1 ELSE 0 END) AS 'QTD_VENDAS_2020',
    SUM(CASE WHEN YEAR(purchase_date) = 2021 THEN 1 ELSE 0 END) AS 'QTD_VENDAS_2021',
    SUM(CASE WHEN YEAR(purchase_date) = 2022 THEN 1 ELSE 0 END) AS 'QTD_VENDAS_2022',
    CAST((((SUM(CASE WHEN YEAR(purchase_date) = 2021 AND DAYOFWEEK(purchase_date) BETWEEN 2 AND 6 THEN 1 ELSE NULL END) - 
    SUM(CASE WHEN YEAR(purchase_date) = 2020 THEN 1 ELSE 0 END)) / 
    SUM(CASE WHEN YEAR(purchase_date) = 2020 THEN 1 ELSE 0 END))) * 100 AS DECIMAL(10,2))
    AS '%VARIACAO_2021_2020',
	CAST((((SUM(CASE WHEN YEAR(purchase_date) = 2022 AND DAYOFWEEK(purchase_date) BETWEEN 2 AND 6 THEN 1 ELSE NULL END) - 
    SUM(CASE WHEN YEAR(purchase_date) = 2021 THEN 1 ELSE 0 END)) / 
    SUM(CASE WHEN YEAR(purchase_date) = 2022 THEN 1 ELSE 0 END))) * 100 AS DECIMAL(10,2))
    AS '%VARIACAO_2022_2021'
FROM hotmart.vendas
WHERE purchase_date BETWEEN TIMESTAMP('2020-01-01') AND TIMESTAMP('2022-12-30')
GROUP BY DIA_SEMANA
ORDER BY FIELD(DIA_SEMANA, 'Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado');
