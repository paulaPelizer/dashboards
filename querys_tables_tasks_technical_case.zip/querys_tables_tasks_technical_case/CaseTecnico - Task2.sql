SELECT a.producer_id, CAST(SUM(b.comission_value) AS DECIMAL(10,2)) as SOMA_COMISSAO
FROM hotmart.produtores AS a
INNER JOIN hotmart.produtos as c ON a.producer_id = c.producer_id
INNER JOIN hotmart.vendas AS b ON c.product_id = b.product_id
WHERE a.registry_date >= timestamp('2019-01-01')
AND c.recovery_active = 1
GROUP BY a.producer_id
ORDER BY SOMA_COMISSAO DESC
LIMIT 5;