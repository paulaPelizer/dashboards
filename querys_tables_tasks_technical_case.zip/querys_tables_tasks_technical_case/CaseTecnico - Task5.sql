SELECT 
	 CASE 
        WHEN a.recovery_active > 0 THEN 'Recovery Active'
        ELSE 'Not Recovery Active'
    END AS recovery_activity_status,
    CAST(SUM(b.comission_value) AS DECIMAL(10,2)) AS total_commission_retention,
    CAST(
        SUM(b.comission_value) / (SELECT SUM(b2.comission_value)
                                            FROM hotmart.produtos AS a2
                                            INNER JOIN hotmart.vendas AS b2 ON a2.product_id = b2.product_id
                                            WHERE a2.registry_date >= TIMESTAMP('2019-01-01')
                                            AND a2.type = 'Curso'
                                            AND EXISTS (SELECT 1 FROM hotmart.vendas WHERE product_id = a2.product_id AND cancelled = 1)
                                           ) * 100 AS DECIMAL(10,2)
    ) AS '%media_retencao'
FROM 
    hotmart.produtos AS a 
INNER JOIN 
    hotmart.vendas AS b ON a.product_id = b.product_id
WHERE 
    a.registry_date >= TIMESTAMP('2019-01-01')
    AND a.type = 'Curso'
GROUP BY 
    a.recovery_active
HAVING 
    SUM(b.cancelled) >= 1;
