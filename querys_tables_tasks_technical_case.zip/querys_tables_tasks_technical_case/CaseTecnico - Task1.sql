WITH PURCHASE_PER_PRODUCT AS (
    SELECT 
        a.niche, 
        a.product_id,
        a.type,
        COUNT(b.purchase_id) AS QTD_PURCHASE
    FROM 
        hotmart.produtos AS a
    INNER JOIN 
        hotmart.vendas AS b ON a.product_id = b.product_id
    WHERE 
        a.member_area_active = 0
        AND a.recovery_active = 1
        AND b.refund = 0
        AND b.cancelled = 0
        AND b.chargeback = 0
    GROUP BY 
        a.niche, a.product_id, a.type
),
MAX_PURCHASE_PER_PRODUCT AS (
    SELECT 
        niche, 
        MAX(QTD_PURCHASE) AS max_vendas
    FROM 
        PURCHASE_PER_PRODUCT
    GROUP BY 
        niche
)
SELECT 
    v.niche AS NICHE, 
    v.product_id AS PRODUCT,
    v.type AS TYPE_PRODUCT,
    v.QTD_PURCHASE
FROM 
    PURCHASE_PER_PRODUCT v
INNER JOIN 
    MAX_PURCHASE_PER_PRODUCT m ON v.niche = m.niche AND v.QTD_PURCHASE = m.max_vendas
ORDER BY 
    v.QTD_PURCHASE DESC;
