WITH produto_vendas AS (
    SELECT 
        b.producer_id,
        COUNT(DISTINCT b.product_id) AS QTD_PRODUTOS_CRIADOS,
        CAST(
            COUNT(b.product_id) / 
            (SELECT COUNT(c.purchase_id)
             FROM hotmart.produtos AS b 
             INNER JOIN hotmart.vendas AS c ON b.product_id = c.product_id
             /*WHERE c.purchase_date >= TIMESTAMP('2023-01-01')*/) * 100
            AS DECIMAL(10,2)
        ) AS CONVERSAO_MESMO_PRODUTO,
        CAST(
            COUNT(c.cancelled) / 
            (SELECT COUNT(c.purchase_id)
             FROM hotmart.produtores AS a
             INNER JOIN hotmart.produtos AS b ON a.producer_id = b.producer_id
             INNER JOIN hotmart.vendas AS c ON b.product_id = c.product_id
             WHERE /*c.purchase_date >= TIMESTAMP('2023-01-01') AND */c.cancelled = 0) * 100
            AS DECIMAL(10,2)
        ) AS APROVACAO,
        COUNT(DISTINCT b.niche) + COUNT(DISTINCT b.type) AS VARIEDADE_DIVERSIDADE
    FROM 
        hotmart.produtos AS b
    INNER JOIN 
        hotmart.vendas AS c ON b.product_id = c.product_id
    /*WHERE 
        c.purchase_date >= TIMESTAMP('2023-01-01')*/
    GROUP BY 
        b.producer_id
),
ranked_produto_vendas AS (
    SELECT 
        *,
        RANK() OVER (
            ORDER BY 
                QTD_PRODUTOS_CRIADOS DESC, 
                VARIEDADE_DIVERSIDADE DESC, 
                APROVACAO DESC, 
                CONVERSAO_MESMO_PRODUTO DESC
        ) AS ranking
    FROM 
        produto_vendas
)
SELECT 
    producer_id,
    QTD_PRODUTOS_CRIADOS,
    CONVERSAO_MESMO_PRODUTO,
    APROVACAO,
    VARIEDADE_DIVERSIDADE,
    ranking
FROM 
    ranked_produto_vendas
ORDER BY 
    ranking;
